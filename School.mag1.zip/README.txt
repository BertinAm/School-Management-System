--------------------------------------------------------------------------------------------------------------------------------------------------------------------->
//In other to run this application on your machine that runs the Windows OS the following things are to be done:

- Firstly, make sure to download netbeans of any version from their official website next you download jdk's latest 
	version from their official website.
-Next you install your netbeans and jdk correctly.

-After installing netbeans and jdk you then download Xampp and install it.

-After installing Xampp you start apache and mysql.

-Next you click the ADMIN button on the mysql tab after clicking the ADMIN button it will open a tab in your default
	browser called phpmyadmin from were you will import the database.

----------------------------------------------------------------------------------------------------------------------------------------------------->
-Then you download the project file for group 6 and extract it.

-After extracting the project file store it in a folder you will easily remember.

-Next you open netbeans and once it has opened you navigate to the file tab and select open project.

-After clicking open project a window will open asking you to select the java application you wchich to open. You
	then navigate while in that window to the folder were the extracted project for group E is found you will then
	see a Java application called school__mag1. You then select it with your mouse and click the button open project
-After clicking the button open project all the classes, jforms and libries will be added automatically.

--------------------------------------------------------------------------------------------------------------------->
-Before running the aplication you will find a folder in the extrated file called database, you then open the folder and you
	you will see a file called school_mag1.sql.

-After viewing the file you then go the page you opened by clicking Admin on the mysql tab and you will see a house like this(🏡) at the top left
	of the phpmyadmin page.

-You then click that house and you will be taking to a page which will show you various tabs like database sql etc but in this case,
	you click the tab called import and an import page will be opened. On this page a button will be seen asking
	you to choose file whose size is not greeater than 40MB. You then click select file and then a window will 
	open which you will use to open the school_mag1.sql file in the database folder found in the extracted project folder

-------------------------------------------------------------------------------------------------->
-You then select the school_mag1.sql and hit the GO button on the lower right of that page after doing that a message
	stating "successful  import of database". After this the database is ready to use.

-You then run the aplication by hitting shift-f6 on your key board.

-If any page should show a bug you then open the page and hit Ctrl-s on the key board.

