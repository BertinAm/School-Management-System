/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author BERTIN FONGE
 */
public class loginNGTest {
    
    public loginNGTest() {
    }

    /**
     * Test of main method, of class login.
     */
    @Test
    public void testMain() {
    }
    
}
